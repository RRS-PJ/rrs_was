package com.korit.projectrrs.dto.walkingRecord.response;

public class WalkingRecordListResponseDto {
}
