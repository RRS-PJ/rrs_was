package com.korit.projectrrs.entity;

public enum WalkingRecordWeatherState {
    SUNNY,
    CLOUDY,
    RAINY,
    SNOWY
}
